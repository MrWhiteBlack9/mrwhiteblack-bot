from .start import register as register_start

def register(dp):
    register_start(dp)
